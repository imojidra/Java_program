package bank_activity;

public class Transaction implements Bank{

	@Override
	public void deposite(Account ac, double amt) {
		// TODO Auto-generated method stub
		System.out.println("Previous Bal. : "+ac.getBalance());
		double newbal = ac.getBalance() + amt;
		ac.setBalance(newbal);
		System.out.println("\n"+amt+" deposited....");
		System.out.println("\nAva. Bal. Is "+ac.getBalance());
	}

	@Override
	public void withdraw(Account ac, double amt) {
		// TODO Auto-generated method stub
		System.out.println("Previous Bal. : "+ac.getBalance());
		double newbal = ac.getBalance() - amt;
		ac.setBalance(newbal);
		System.out.println("\n"+amt+" Withdraw....");
		System.out.println("\nAva. Bal. Is "+ac.getBalance());
	}

}
